import home from './home';

const routes = [
    ...home,
];

export default routes;
